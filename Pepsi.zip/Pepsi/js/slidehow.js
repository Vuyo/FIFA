var images = new Array ("Pepsi-LandingPage.jpg", "Pepsi-Brands-All.jpg", "Pepsi-Brands-All.jpg" ,"Pepsi-Brands-Max.jpg", "Pepsi-Brands-Regular.jpg", "Pepsi-HomeBanner.jpg", "Pepsi-LastImage.jpg", "Pepsi-Mockup.jpg","Pepsi-Subscribe.jpg");

var i = 0

function sunSlideShow()
{
    document.getElementById("pepsiSlider").src = ( "img/" + images[i] );

    if (i<9)
    {
        i++;
    }

    else
        i = 0;

    setTimeout("sunSlideShow()", 3000);
}
sunSlideShow();