
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
    <title>Report page</title>
</head>
<body>
    <br/>
  <button onclick="goBack()">Go to previous page</button>

<script>
function goBack() {
    window.history.back();
}
</script>
    <br/>
<br/>
    </body>
</html>

