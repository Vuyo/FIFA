<html>
<body>
<hr>
<div id='footer'>Copyright <?php echo date('Y'); ?> &copy; <?php echo $domain; ?></div>
</body>
</html>