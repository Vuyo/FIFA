<?php
 
require_once("mail.func.php");
require_once("user.func.php");
require_once("forms.func.php");
//require_once("login.func.php");
require_once("validations.func.php");

?>